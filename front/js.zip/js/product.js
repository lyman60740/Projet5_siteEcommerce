// Manipulation d'URLSearchParams

const url = new URL(document.location);

// la propriété "searchParams" de "url" nous retourne un objet de type "URLSearchParams"

 const searchParams = url.searchParams;
urlData = searchParams.get('id');
console.log(urlData)

fetch(`http://localhost:3000/api/products/${urlData}`)
  .then(function(res) {
    if (res.ok) {
      return res.json();
    }
  })
  .then(function(value) {
    console.log(value.imageUrl)
    // Inserer la bonne structure
    /*
  document.querySelector('#items').insertAdjacentHTML('beforeend',
  `<a href="./product.html?id=${value[i]._id}">
  <article>
  <img src="${value[i].imageUrl}" alt="${value[i].altTxt}">
  <h3 class="productName">${value[i].name}</h3>
  <p class="productDescription">${value[i].description}</p>
</article>
</a>`
)
*/

  })
  .catch(function(err) {
    // Une erreur est survenue
  });

